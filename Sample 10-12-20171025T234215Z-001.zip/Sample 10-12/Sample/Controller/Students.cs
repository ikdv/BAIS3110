﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data;
using System.Data.SqlClient;

namespace BAIS3150CodeSampleSystem.Controller
{
    public class Students
    {
        public bool AddStudent(Student p_clsStudent, string programCode)
        {
            SqlConnection BAIS3150Connection; //reference sql connection  - null reference

            BAIS3150Connection = new SqlConnection(); //intanciate connection in the memory and pointing it

            BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\v11.0; Initial Catalog= BAIS3150; Integrated Security=true"; // backslash 
            //BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\MSSQLLocalDB; Initial Catalog= BAIS3150; Integrated Security=SSPI"; // backslash 

            // 2. Create Command
            SqlCommand BAIS3150Command;

            BAIS3150Command = new SqlCommand();

            BAIS3150Command.CommandType = CommandType.StoredProcedure;

            BAIS3150Command.Connection = BAIS3150Connection;
            BAIS3150Command.CommandText = "AddStudent";


            SqlParameter ProgramCode;
            ProgramCode = new SqlParameter();
            ProgramCode.ParameterName = "programCode";
            ProgramCode.SqlDbType = SqlDbType.NVarChar;
            ProgramCode.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            ProgramCode.Value = programCode;

            BAIS3150Command.Parameters.Add(ProgramCode);

            SqlParameter FirstName;
            FirstName = new SqlParameter();
            FirstName.ParameterName = "firstName";
            FirstName.SqlDbType = SqlDbType.NVarChar;
            FirstName.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            FirstName.Value = p_clsStudent.FirstName;

            BAIS3150Command.Parameters.Add(FirstName);

            SqlParameter LastName;
            LastName = new SqlParameter();
            LastName.ParameterName = "lastName";
            LastName.SqlDbType = SqlDbType.NVarChar;
            LastName.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            LastName.Value = p_clsStudent.LastName;

            BAIS3150Command.Parameters.Add(LastName);

            SqlParameter Email;
            Email = new SqlParameter();
            Email.ParameterName = "email";
            Email.SqlDbType = SqlDbType.NVarChar;
            Email.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            Email.Value = p_clsStudent.Email;

            BAIS3150Command.Parameters.Add(Email);



            BAIS3150Connection.Open();
            bool isError = true;
            int isSuccess = 0;

            try
            {
                isSuccess = BAIS3150Command.ExecuteNonQuery(); //.ExecuteReader(); execute reader returns a datareader 
                                                               // ExecuteNonQuery DELETE / UPDATE /INSERT
            }
            catch (SqlException sqlEx)
            {

            }
            if (isSuccess >= 1)
                isError = false;

            BAIS3150Connection.Close();

            return isError;

        }
        
        public bool UpdateStudent(Student p_clsStudent)
        {
            SqlConnection BAIS3150Connection; //reference sql connection  - null reference

            BAIS3150Connection = new SqlConnection(); //intanciate connection in the memory and pointing it

            BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\v11.0; Initial Catalog= BAIS3150; Integrated Security=true"; // backslash 
            //BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\MSSQLLocalDB; Initial Catalog= BAIS3150; Integrated Security=SSPI"; // backslash 

            // 2. Create Command
            SqlCommand BAIS3150Command;

            BAIS3150Command = new SqlCommand();

            BAIS3150Command.CommandType = CommandType.StoredProcedure;

            BAIS3150Command.Connection = BAIS3150Connection;
            BAIS3150Command.CommandText = "UpdateStudent";

            /*
            SqlParameter ProgramCode;
            ProgramCode = new SqlParameter();
            ProgramCode.ParameterName = "programCode";
            ProgramCode.SqlDbType = SqlDbType.NVarChar;
            ProgramCode.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            ProgramCode.Value =  programCode;
            BAIS3150Command.Parameters.Add(ProgramCode);
            */
            SqlParameter FirstName;
            FirstName = new SqlParameter();
            FirstName.ParameterName = "firstName";
            FirstName.SqlDbType = SqlDbType.NVarChar;
            FirstName.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            FirstName.Value = p_clsStudent.FirstName;

            BAIS3150Command.Parameters.Add(FirstName);

            SqlParameter LastName;
            LastName = new SqlParameter();
            LastName.ParameterName = "lastName";
            LastName.SqlDbType = SqlDbType.NVarChar;
            LastName.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            LastName.Value = p_clsStudent.LastName;

            BAIS3150Command.Parameters.Add(LastName);

            SqlParameter Email;
            Email = new SqlParameter();
            Email.ParameterName = "email";
            Email.SqlDbType = SqlDbType.NVarChar;
            Email.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            Email.Value = p_clsStudent.Email;

            BAIS3150Command.Parameters.Add(Email);
            
            SqlParameter StudentID;
            StudentID = new SqlParameter();
            StudentID.ParameterName = "studentID";
            StudentID.SqlDbType = SqlDbType.NVarChar;
            StudentID.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            StudentID.Value =p_clsStudent.StundentID;

            BAIS3150Command.Parameters.Add(StudentID);
            


            BAIS3150Connection.Open();
            bool isError = true;
            int isSuccess = 0;

            try
            {
                isSuccess = BAIS3150Command.ExecuteNonQuery(); //.ExecuteReader(); execute reader returns a datareader 
                                                               // ExecuteNonQuery DELETE / UPDATE /INSERT
            }
            catch (SqlException sqlEx)
            {

            }
            if (isSuccess >= 1)
                isError = false;

            BAIS3150Connection.Close();

            return isError;

        }

        public bool DeleteStudent(string studentID)
        {
            SqlConnection BAIS3150Connection; //reference sql connection  - null reference

            BAIS3150Connection = new SqlConnection(); //intanciate connection in the memory and pointing it

            BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\v11.0; Initial Catalog= BAIS3150; Integrated Security=true"; // backslash 
            //BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\MSSQLLocalDB; Initial Catalog= BAIS3150; Integrated Security=SSPI"; // backslash 

            // 2. Create Command
            SqlCommand BAIS3150Command;

            BAIS3150Command = new SqlCommand();

            BAIS3150Command.CommandType = CommandType.StoredProcedure;

            BAIS3150Command.Connection = BAIS3150Connection;
            BAIS3150Command.CommandText = "DeleteStudent";

            SqlParameter StudentID;
            StudentID = new SqlParameter();
            StudentID.ParameterName = "studentID";
            StudentID.SqlDbType = SqlDbType.NVarChar;
            StudentID.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            StudentID.Value = studentID;

            BAIS3150Command.Parameters.Add(StudentID);



            BAIS3150Connection.Open();
            bool isError = true;
            int isSuccess = 0;

            try
            {
                isSuccess = BAIS3150Command.ExecuteNonQuery(); //.ExecuteReader(); execute reader returns a datareader 
                                                               // ExecuteNonQuery DELETE / UPDATE /INSERT
            }
            catch (SqlException sqlEx)
            {

            }
            if (isSuccess >= 1)
                isError = false;

            BAIS3150Connection.Close();

            return isError;

        }
        public List<Student> GetStudents(string programCode)
        {

            SqlConnection BAIS3150Connection; //reference sql connection  - null reference

            BAIS3150Connection = new SqlConnection(); //intanciate connection in the memory and pointing it

            BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\v11.0; Initial Catalog= BAIS3150; Integrated Security=true"; // backslash 
            //BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\MSSQLLocalDB; Initial Catalog= BAIS3150; Integrated Security=SSPI"; // backslash 

            // 2. Create Command
            SqlCommand BAIS3150Command;

            BAIS3150Command = new SqlCommand();

            BAIS3150Command.CommandType = CommandType.StoredProcedure;

            BAIS3150Command.Connection = BAIS3150Connection;
            BAIS3150Command.CommandText = "GetStudents";


            SqlParameter ProgramCode;
            ProgramCode = new SqlParameter();
            ProgramCode.ParameterName = "programCode";
            ProgramCode.SqlDbType = SqlDbType.NVarChar;
            ProgramCode.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            ProgramCode.Value = programCode;
            BAIS3150Command.Parameters.Add(ProgramCode);


            BAIS3150Connection.Open();
            bool isError = true;
            int isSuccess = 0;

            SqlDataReader BAIS3150DataReader;
          
            List<Student> EnrolledStudent;
            EnrolledStudent = new List<Student>();


BAIS3150DataReader = BAIS3150Command.ExecuteReader();
            try
            {
                
                //.ExecuteReader(); execute reader returns a datareader 
                // ExecuteNonQuery DELETE / UPDATE /INSERT
                //dt.Load(BAIS3150DataReader);

                while (BAIS3150DataReader.Read())
                {
                    Student aStudent = new Student();

                    aStudent.StundentID = BAIS3150DataReader["studentID"].ToString();
                    aStudent.FirstName = BAIS3150DataReader["firstName"].ToString();
                    aStudent.LastName = BAIS3150DataReader["lastName"].ToString();
                    aStudent.Email = BAIS3150DataReader["email"].ToString();

                    EnrolledStudent.Add(aStudent);

                }
            }
            catch (SqlException sqlEx)
            {

            }
            if (isSuccess >= 1)
                isError = false;

            BAIS3150Connection.Close();

            return EnrolledStudent;

        }
        public Student GetStudent(string studentID)
        {

            SqlConnection BAIS3150Connection; //reference sql connection  - null reference

            BAIS3150Connection = new SqlConnection(); //intanciate connection in the memory and pointing it

            BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\v11.0; Initial Catalog= BAIS3150; Integrated Security=true"; // backslash 
            //BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\MSSQLLocalDB; Initial Catalog= BAIS3150; Integrated Security=SSPI"; // backslash 

            // 2. Create Command
            SqlCommand BAIS3150Command;

            BAIS3150Command = new SqlCommand();

            BAIS3150Command.CommandType = CommandType.StoredProcedure;

            BAIS3150Command.Connection = BAIS3150Connection;
            BAIS3150Command.CommandText = "GetStudent";


            SqlParameter StudentID;
            StudentID = new SqlParameter();
            StudentID.ParameterName = "studentID";
            StudentID.SqlDbType = SqlDbType.NVarChar;
            StudentID.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            StudentID.Value = studentID;
            BAIS3150Command.Parameters.Add(StudentID);


            BAIS3150Connection.Open();
            bool isError = true;
            int isSuccess = 0;
            DataTable dt = new DataTable();
            SqlDataReader BAIS3150DataReader;
            Student EnrolledStudent = new Student();
            
            try
            {
                BAIS3150DataReader = BAIS3150Command.ExecuteReader();
                //.ExecuteReader(); execute reader returns a datareader 
                // ExecuteNonQuery DELETE / UPDATE /INSERT
                //dt.Load(BAIS3150DataReader);

                while (BAIS3150DataReader.Read())
                {
                    EnrolledStudent.StundentID = BAIS3150DataReader["studentID"].ToString();
                    EnrolledStudent.FirstName = BAIS3150DataReader["firstName"].ToString();
                    EnrolledStudent.LastName= BAIS3150DataReader["lastName"].ToString();
                    EnrolledStudent.Email = BAIS3150DataReader["email"].ToString();
                    
                }
            }
            catch (SqlException sqlEx)
            {

            }
            if (isSuccess >= 1)
                isError = false;

            BAIS3150Connection.Close();

            return EnrolledStudent;

        }
    }
}