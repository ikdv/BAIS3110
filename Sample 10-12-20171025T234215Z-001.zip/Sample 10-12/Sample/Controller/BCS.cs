﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace BAIS3150CodeSampleSystem.Controller
{
    public class BCS2
    {
        private Program m_clsProgram;
        private Student m_clsStudent;

        public Program Program
        {
            get { return m_clsProgram; }
            set { m_clsProgram = value; }
        }
        public Student Student
        {
            get { return m_clsStudent;  }
            set { m_clsStudent = value; }
        }
        public BCS2()
        {
            m_clsProgram = new Program();
            m_clsStudent = new Student();


        }
        public bool CreateProgram(string programCode, string description)
        {
            /*m_clsProgram.ProgramCode = programCode;
            m_clsProgram.Description = description;*/

            Programs ProgramManager = new Programs();

            bool result = ProgramManager.AddProgram(programCode, description);
            return result;
        }
        public bool EnrollStudent(Student p_clsStudent, string programCode)
        {
            Students StudentManager = new Students();

            bool result = StudentManager.AddStudent(p_clsStudent, programCode);
            return result;
        }
        public Student FindStudent(string studentID)
        {
            Students StudentManager = new Students();
            m_clsStudent = StudentManager.GetStudent(studentID);
            return m_clsStudent;
        }
        public bool UpdateStudent(Student p_clsStudent)
        {
            Students StudentManager = new Students();

            bool result = StudentManager.UpdateStudent(p_clsStudent);
            return result;
        }
        public bool RemoveStudent(string studentID)
        {
            Students StudentManager = new Students();
            bool result = StudentManager.DeleteStudent(studentID);
            return result;
        }
        public Program FindProgram(string programCode)
        {
            Programs ProgramManager = new Programs();
            m_clsProgram = ProgramManager.GetProgram(programCode);
            return m_clsProgram;
        }





    }
}