﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data;
using System.Data.SqlClient;

namespace BAIS3150CodeSampleSystem.Controller
{
    public class Programs
    {
        public bool AddProgram(string programCode, string description)
        {
            SqlConnection BAIS3150Connection; //reference sql connection  - null reference

            BAIS3150Connection = new SqlConnection(); //intanciate connection in the memory and pointing it

            BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\v11.0; Initial Catalog= BAIS3150; Integrated Security=true"; // backslash 
            //BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\MSSQLLocalDB; Initial Catalog= BAIS3150; Integrated Security=SSPI"; // backslash 

            // 2. Create Command
            SqlCommand BAIS3150Command;

            BAIS3150Command = new SqlCommand();

            BAIS3150Command.CommandType = CommandType.StoredProcedure;

            BAIS3150Command.Connection = BAIS3150Connection;
            BAIS3150Command.CommandText = "AddProgram";


            SqlParameter ProgramCode;
            ProgramCode = new SqlParameter();
            ProgramCode.ParameterName = "programCode";
            ProgramCode.SqlDbType = SqlDbType.NVarChar;
            ProgramCode.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            ProgramCode.Value = programCode;
            BAIS3150Command.Parameters.Add(ProgramCode);

            SqlParameter Description;
            Description = new SqlParameter();
            Description.ParameterName = "description";
            Description.SqlDbType = SqlDbType.NVarChar;
            Description.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
            Description.Value = description;

            BAIS3150Command.Parameters.Add(Description);



            BAIS3150Connection.Open();
            bool isError = true;
            int isSuccess = 0;
            SqlDataReader BAIS3150DataReader;
            try
            {
                isSuccess = BAIS3150Command.ExecuteNonQuery(); //.ExecuteReader(); execute reader returns a datareader 
                                                               // ExecuteNonQuery DELETE / UPDATE /INSERT
            }
            catch (SqlException sqlEx)
            {

            }
            if (isSuccess >= 1)
                isError = false;

            BAIS3150Connection.Close();

            return isError;

        }

       
        public DataTable GetPrograms()
        {
            SqlConnection BAIS3150Connection; //reference sql connection  - null reference

            BAIS3150Connection = new SqlConnection(); //intanciate connection in the memory and pointing it

            BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\v11.0; Initial Catalog= BAIS3150; Integrated Security=true"; // backslash 
            //BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\MSSQLLocalDB; Initial Catalog= BAIS3150; Integrated Security=SSPI"; // backslash 

            // 2. Create Command
            SqlCommand BAIS3150Command;

            BAIS3150Command = new SqlCommand();

            BAIS3150Command.CommandType = CommandType.StoredProcedure;

            BAIS3150Command.Connection = BAIS3150Connection;
            BAIS3150Command.CommandText = "GetPrograms";


            BAIS3150Connection.Open();
            bool isError = true;
            int isSuccess = 0;
            DataTable dt = new DataTable();

            SqlDataReader BAIS3150DataReader;
            try
            {
                BAIS3150DataReader = BAIS3150Command.ExecuteReader(); //.ExecuteReader(); execute reader returns a datareader 

                dt.Load(BAIS3150DataReader);
                //while (BAIS3150DataReader.Read())
                //{
                //    string koko = (BAIS3150DataReader.GetValue(0) + " - " + BAIS3150DataReader.GetValue(1) );
                //}                                                      
            }
            catch (SqlException sqlEx)
            {

            }
            if (isSuccess >= 1)
                isError = false;

            BAIS3150Connection.Close();

            return dt;

        }
        public Program GetProgram(string programCode)
        {
            /*
            

            return isError;
            */
            Students StudentManager = new Students();

            Program ActiveProgram = new Program();

            List<Student> EnrolledStudent;

            EnrolledStudent = StudentManager.GetStudents(programCode);
            if (EnrolledStudent.Count > 0)
            {
                SqlConnection BAIS3150Connection; //reference sql connection  - null reference

                BAIS3150Connection = new SqlConnection(); //intanciate connection in the memory and pointing it

                BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\v11.0; Initial Catalog= BAIS3150; Integrated Security=true"; // backslash 
                                                                                                                                             //BAIS3150Connection.ConnectionString = "Data Source = (localDB)\\MSSQLLocalDB; Initial Catalog= BAIS3150; Integrated Security=SSPI"; // backslash 

                // 2. Create Command
                SqlCommand BAIS3150Command;

                BAIS3150Command = new SqlCommand();

                BAIS3150Command.CommandType = CommandType.StoredProcedure;

                BAIS3150Command.Connection = BAIS3150Connection;
                BAIS3150Command.CommandText = "GetProgram";


                SqlParameter ProgramCode;
                ProgramCode = new SqlParameter();
                ProgramCode.ParameterName = "programCode";
                ProgramCode.SqlDbType = SqlDbType.NVarChar;
                ProgramCode.Direction = ParameterDirection.Input; // important because default is input , change for put parameters
                ProgramCode.Value = programCode;
                BAIS3150Command.Parameters.Add(ProgramCode);


                BAIS3150Connection.Open();
                bool isError = true;
                int isSuccess = 0;
                SqlDataReader BAIS3150DataReader;

                try
                {
                    BAIS3150DataReader = BAIS3150Command.ExecuteReader(); //.ExecuteReader(); execute reader returns a datareader 
                                                                          // ExecuteNonQuery DELETE / UPDATE /INSERT
                    while (BAIS3150DataReader.Read())
                    {
                        ActiveProgram.ProgramCode = BAIS3150DataReader["programCode"].ToString();
                        ActiveProgram.Description = BAIS3150DataReader["description"].ToString();
                      

                    }
                }
                catch (SqlException sqlEx)
                {

                }
                if (isSuccess >= 1)
                    isError = false;

                BAIS3150Connection.Close();

            }
          
            return ActiveProgram;
        }
    }
}