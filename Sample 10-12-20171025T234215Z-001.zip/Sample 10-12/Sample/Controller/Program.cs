﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data;
using System.Data.SqlClient;

namespace BAIS3150CodeSampleSystem.Controller
{
    public class Program
    {
        
        private string programCode;
        private string description;
        //public List<Student> EnrolledStudent;
        public string ProgramCode
        {
            get { return programCode; }
            set { programCode = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
      

    }
}