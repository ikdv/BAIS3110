﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using BAIS3150CodeSampleSystem.Controller;

namespace BAIS3150CodeSampleSystem
{
    public partial class EnrollStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            msgError.Visible = false;
            msgSuccess.Visible = false;
            init();
            

        }
        private void init()
        {
            if (!IsPostBack)
            {
                msgError.Visible = false;
                msgSuccess.Visible = false;
                GetPrograms();
            }
        }
        private void GetPrograms()
        {
            Programs ProgramManager = new Programs();

            using (DataTable dt = ProgramManager.GetPrograms())
            {
                int jiji = dt.Rows.Count;

                foreach (DataRow jii in dt.Rows)
                {
                    ListItem kokoy = new ListItem(jii["description"].ToString(), jii["programCode"].ToString());
                    lstPrograms.Items.Add(kokoy);



                    //Response.Write(jii["description"]);
                }

                ////string koko = dt.Rows[0]["description"].ToString();

                //Response.Write(koko);
                // contine using dt
            }//here the table is disposed
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BCS2 RequestDirector = new BCS2();

            Student student = new Student();

            student.FirstName = txtFirstName.Text;
            student.LastName = txtLastName.Text;
            student.Email = txtEmail.Text;


           



            bool koko = RequestDirector.EnrollStudent(student, lstPrograms.Value);
            //Response.Write(koko);

            if (koko)
               msgError.Visible = true;
            else
               msgSuccess.Visible = true;

            Program Programs = new Program();

           


        }
    }
}