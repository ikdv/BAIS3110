﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BAIS3150CodeSampleSystem.Controller;

namespace BAIS3150CodeSampleSystem
{
    public partial class ModifyStudent : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
           
           

            init();
        }
        private void init()
        {
            if (!IsPostBack)
            {
                msgError.Visible = false;
                msgSuccess.Visible = false;
                msgErrorFind.Visible = false;
                msgSuccessFind.Visible = false;
                GetPrograms();
            }
        }
        private void GetPrograms()
        {
            Programs ProgramManager = new Programs();

            

            using (DataTable dt = ProgramManager.GetPrograms())
            {
                int jiji = dt.Rows.Count;

               
                    foreach (DataRow jii in dt.Rows)
                    {
                        ListItem kokoy = new ListItem(jii["description"].ToString(), jii["programCode"].ToString());
                        lstPrograms.Items.Add(kokoy);



                        //Response.Write(jii["description"]);
                    }
                   
               

                ////string koko = dt.Rows[0]["description"].ToString();

                //Response.Write(koko);
                // contine using dt
            }//here the table is disposed
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            BCS2 RequestDirector = new BCS2();
            Student EnrolledStudent = new Student();
            EnrolledStudent.FirstName = txtFirstName.Text;
            EnrolledStudent.LastName = txtLastName.Text;
            EnrolledStudent.Email = txtEmail.Text;
            EnrolledStudent.StundentID = hfStudentID.Value;
            bool koko = RequestDirector.UpdateStudent(EnrolledStudent );
            if (koko)
                msgError.Visible = true;
            
            else
                msgSuccess.Visible = true;

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            hfStudentID.Value = txtStudentID.Text;
            BCS2 RequestDirector = new BCS2();

            Student m_clsStudents = new Student();

            m_clsStudents = RequestDirector.FindStudent(txtStudentID.Text);

            Students Students = new Students();

            txtFirstName.Text = m_clsStudents.FirstName;
            txtLastName.Text = m_clsStudents.LastName;
            txtEmail.Text = m_clsStudents.Email;
            /*

            using (DataTable dt = Students.GetStudent(txtStudentID.Text))
            {
                int jiji = dt.Rows.Count;
                if (jiji >= 1)
                {

                    foreach (DataRow jii in dt.Rows)
                    {
                        txtFirstName.Text = jii["firstName"].ToString();
                        txtLastName.Text = jii["lastName"].ToString();
                        txtEmail.Text = jii["email"].ToString();
                        txtProgramCode.Text = jii["programCode"].ToString();
                        //lstPrograms.Items.
                        //lstPrograms.DataTextField = jii["description"].ToString();
                        //lblProgramCode.Text = jii["programCode"].ToString();
                        //lblProgram.Text = jii["description"].ToString();


                    }
                    msgSuccessFind.Visible = true;
                }
                else
                {
                    clearForm();
                    msgErrorFind.Visible = true;
                }

            }//here the table is disposed
            */

        }
        private void clearForm()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
           
            txtProgramCode.Text = "";
            txtEmail.Text = "";
        }
    }
}