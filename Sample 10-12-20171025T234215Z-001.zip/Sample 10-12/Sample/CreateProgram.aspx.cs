﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAIS3150CodeSampleSystem.Controller;

namespace BAIS3150CodeSampleSystem
{
    public partial class CreateProgram : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            msgError.Visible = false;
            msgSuccess.Visible = false;
            init();   
        }
        private void init()
        {
            if (!IsPostBack)
            {
                msgError.Visible = false;
                msgSuccess.Visible = false;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            BCS2 RequestDirector = new BCS2();

            bool koko = RequestDirector.CreateProgram(txtProgramCode.Text, txtDescription.Text);
            
            if (koko)
               msgError.Visible = true;
            else
               msgSuccess.Visible = true;


        }
    }
}