﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BAIS3150CodeSampleSystem.Controller;

namespace BAIS3150CodeSampleSystem
{
    public partial class FindStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            msgError.Visible = false;
            msgSuccess.Visible = false;

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BCS2 RequestDirector = new BCS2();

            Student m_clsStudents = new Student();

            m_clsStudents = RequestDirector.FindStudent(txtStudentID.Text);
        
            Students Students = new Students();

            lblFirstName.Text = m_clsStudents.FirstName;
            lblLastName.Text = m_clsStudents.LastName;
            lblEmail.Text = m_clsStudents.Email;
            //lblProgramCode.Text = jii["programCode"].ToString();
            //lblProgram.Text = jii["description"].ToString();
            /*
            using (DataTable dt = Students.GetStudent(txtStudentID.Text))
            {
                int jiji = dt.Rows.Count;
                if (jiji >= 1)
                {
                    foreach (DataRow jii in dt.Rows)
                    {
                        lblFirstName.Text = jii["firstName"].ToString();
                        lblLastName.Text = jii["lastName"].ToString();
                        lblEmail.Text = jii["email"].ToString();
                        lblProgramCode.Text = jii["programCode"].ToString();
                        lblProgram.Text = jii["description"].ToString();


                    }
                    msgSuccess.Visible = true;
                }

                else
                {
                    msgError.Visible = true;
                }

                
            }//here the table is disposed
            */
        

        }
    }
}